package com.yaoa.mall;

import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

 
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:/spring.xml" })
public abstract class AbstractTest {
	
	protected ObjectMapper jsonMapper;

	public AbstractTest(){
		jsonMapper = new ObjectMapper();
		jsonMapper.configure(MapperFeature.DEFAULT_VIEW_INCLUSION, false);
	}
	
	public String getJson(Object result){
		try {
			return jsonMapper.writeValueAsString(result);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public String getJson(Object result , Class<?> viewClass){
		try {
			return jsonMapper.writerWithView(viewClass).writeValueAsString(result);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
		return null;
	}
}

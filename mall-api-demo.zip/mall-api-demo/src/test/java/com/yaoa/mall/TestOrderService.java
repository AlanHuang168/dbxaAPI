package com.yaoa.mall;

import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

import org.apache.http.HttpResponse;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.junit.Test;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.yaoa.dbxa.Utils;
import com.yaoa.dbxa.request.OrderCreateRequest;
import com.yaoa.dbxa.request.OrderQueryRequest;
import com.yaoa.dbxa.response.OrderCreateResponse;
import com.yaoa.dbxa.response.OrderQueryResponse;
import com.yaoa.dbxa.service.DbxaClient;


public class TestOrderService {
 
	
	private static final String APPID= "80b4a370075d9de";//"eeb879a0a13a190";

	private static final String SECRET = "E5KR8F0EHNFpda38CrVvENaGeZrEaJnr";//"Tw3mBRFtDacwpyZ26WTSnWaFgaEHLKaR";
	
	/**
	 * 测试下单
	 */
	//@Test
	public void crateOrderTest(){
		OrderCreateRequest request = new OrderCreateRequest();
		request.setSkuNumber("HuaFei-10");
		request.setPhone("138001380000");
		request.setQuantity(1);
		request.setOutTradeNo("1499928975065");//(String.valueOf(System.currentTimeMillis()));
		request.setCallbackUrl("http://alan.juor.cn/order/callBack");
		
		ObjectMapper mapper = new ObjectMapper(); 
		String json;
		try {
			json = mapper.writeValueAsString(request);
			System.out.println(json);
			Map<String, String> map = new HashMap<String, String>();  
			map = mapper.readValue(json, new TypeReference<HashMap<String,String>>(){});  
			System.out.println(map);
			String sign = Utils.md5(map, SECRET);
			System.out.println(sign);
			request.setSign(sign);
			OrderCreateResponse response = DbxaClient.getInstance(APPID, SECRET).createOrder(request);
			System.out.println(response);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	 
	private static final CloseableHttpClient httpClient = HttpClients.createDefault();
	/**
	 * 测试订单回调
	 * 在大白小爱平台下单后  回调
	 */
	//@Test
	public void testOrderCallBack() {
		String callUrl = "http://alan.juor.cn/order/callBack";
		
		Map<String,String> map = new TreeMap<>();
		map.put("orderNo", "2017070000016");
		map.put("outTradeNo", "1499928975065");
		map.put("deliveryStatus", "301");
		map.put("orderStatus", "203");
		
		ObjectMapper mapper = new ObjectMapper(); 
		String sign = Utils.md5(map,SECRET);
		String json;
		try {
			map.put("sign", sign);
			json = mapper.writeValueAsString(map);
			HttpPost post = new HttpPost(callUrl);
			post.setConfig(RequestConfig.custom().setConnectTimeout(5000)
					.setConnectionRequestTimeout(1000)  
			        .setSocketTimeout(10000).build());
			post.setEntity(new StringEntity(json, ContentType.APPLICATION_JSON));
			HttpResponse resp = httpClient.execute(post);
			String content = Utils.readAll(resp.getEntity().getContent());
			System.out.println(content);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void queryOrder(){
		OrderQueryRequest request = new OrderQueryRequest();
		request.setOrderNo("2017070000016");
		ObjectMapper mapper = new ObjectMapper(); 
		String json;
		try {
			json = mapper.writeValueAsString(request);
			System.out.println(json);
			Map<String, String> map = new HashMap<String, String>();  
			map = mapper.readValue(json, new TypeReference<HashMap<String,String>>(){});  
			System.out.println(map);
			String sign = Utils.md5(map, SECRET);
			System.out.println(sign);
			request.setSign(sign);
			OrderQueryResponse response = DbxaClient.getInstance(APPID, SECRET).queryOrder(request);
			System.out.println(response);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}

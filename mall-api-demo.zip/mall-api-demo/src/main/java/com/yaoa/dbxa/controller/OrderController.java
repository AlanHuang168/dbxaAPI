/*
 * Copyright 2015-2016 Yaoa & Co., Ltd.
 */
package com.yaoa.dbxa.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.yaoa.dbxa.form.OrderCallbackForm;


@Controller
@RequestMapping("/order")
public class OrderController {

	@ResponseBody
	@RequestMapping(value="/callBack")
	public void callBack(@RequestBody OrderCallbackForm form,HttpServletRequest request , HttpServletResponse response) {
		 System.out.println(form.toString());
		 try {
			response.getWriter().write("success");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@ResponseBody
	@RequestMapping(value="/test")
	public void test(HttpServletRequest request , HttpServletResponse response) {
		 System.out.println("Hello word");
	}
}

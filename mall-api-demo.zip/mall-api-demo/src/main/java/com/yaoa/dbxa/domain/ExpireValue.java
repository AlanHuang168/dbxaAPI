/*
 * Copyright 2015-2016 Yaoa & Co., Ltd.
 */
package com.yaoa.dbxa.domain;
 
public class ExpireValue<T> {

	private T value;

	private long expireTime; ;

	public ExpireValue(T value , int expiresIn){
		this.value = value;
		this.expireTime = System.currentTimeMillis() + expiresIn * 1000;
	}
	
	public T getValue(){
		if (expireTime > System.currentTimeMillis()) {
			return value;
		}else{
			return null;
		}
	}
}

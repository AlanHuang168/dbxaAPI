
package com.yaoa.dbxa.domain;

public class Detail {

	private long skuId;
	
	private int quantity;
	
	private String accountNo;

	public long getSkuId() {
		return skuId;
	}

	public int getQuantity() {
		return quantity;
	}

	public String getAccountNo() {
		return accountNo;
	}

	public void setSkuId(long skuId) {
		this.skuId = skuId;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}
}

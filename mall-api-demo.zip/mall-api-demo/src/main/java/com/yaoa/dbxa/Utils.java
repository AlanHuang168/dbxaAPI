package com.yaoa.dbxa;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;

import org.apache.commons.codec.digest.DigestUtils;

 

/**
 * 工具
 * @author Alan
 *
 */
public class Utils {
	
	public static String md5(Map<String, String> parameters, String key) {
		StringBuilder buff = getParam(parameters);
		buff.append("&key=");
		buff.append(key);
		String sign = DigestUtils.md5Hex(buff.toString());
		return sign.toUpperCase();
	}
	/**
	 * 组织支付参数
	 * @param parameters 
	 * @return
	 */
	public static StringBuilder getParam(Map<String, String> parameters){
		TreeMap<String , String> sortedMap ;
		if(parameters instanceof TreeMap){
			sortedMap = (TreeMap<String, String>) parameters;
		}else{
			sortedMap = new TreeMap<String, String>(parameters);
		}
		StringBuilder buff = new StringBuilder();
		for (Entry<String, String> entry : sortedMap.entrySet()) {
			String name = entry.getKey();
			if("sign".equals(name)){
				continue;
			}
			String value = entry.getValue();
			if(null == value ){
				continue;
			}
			buff.append("&").append(name).append("=").append(value);
		}
		if(buff.length() > 0){
			buff.delete(0, 1);
		}
		return buff;
	}
	
	public static String readAll(InputStream in) throws IOException {
		try {
			StringBuilder buff = new StringBuilder();
			BufferedReader reader = new BufferedReader(new InputStreamReader(in));
			String line;
			while((line = reader.readLine()) != null){
				buff.append(line).append(System.lineSeparator());
			}
			return buff.toString();
		} finally {
			in.close();
		}
	}
}

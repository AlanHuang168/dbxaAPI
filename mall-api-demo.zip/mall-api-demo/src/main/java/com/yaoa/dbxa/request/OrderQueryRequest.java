/*
 * Copyright 2015-2016 Yaoa & Co., Ltd.
 */
package com.yaoa.dbxa.request;

public class OrderQueryRequest {

	private String outTradeNo;//客户订单编号 
	
	private String orderNo;//备注
	
	private String sign;//签名

	public String getOutTradeNo() {
		return outTradeNo;
	}

	public void setOutTradeNo(String outTradeNo) {
		this.outTradeNo = outTradeNo;
	}

	public String getOrderNo() {
		return orderNo;
	}

	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}

	public String getSign() {
		return sign;
	}

	public void setSign(String sign) {
		this.sign = sign;
	}

	
	
}

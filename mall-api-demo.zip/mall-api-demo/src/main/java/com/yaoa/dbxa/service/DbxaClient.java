/*
 * Copyright 2015-2016 Yaoa & Co., Ltd.
 */
package com.yaoa.dbxa.service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClientBuilder;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.yaoa.dbxa.domain.ExpireValue;
import com.yaoa.dbxa.request.OrderCreateRequest;
import com.yaoa.dbxa.request.OrderQueryRequest;
import com.yaoa.dbxa.response.OrderCreateResponse;
import com.yaoa.dbxa.response.OrderQueryResponse;

public class DbxaClient {

	private static final ObjectMapper mapper = new ObjectMapper();

	private static Map<String, ExpireValue<String>> accessTokenMap = new HashMap<String, ExpireValue<String>>();

	private static final Log logger = LogFactory.getLog(DbxaClient.class);

	private static Map<String, DbxaClient> instanceMap = new HashMap<String, DbxaClient>();

	private String appId;

	private String secret;

	private static final  String accessTokenUrl="http://gift.app.aa.com/oauth2/access_token";
	
	private static final String createOrderUrl="http://gift.app.aa.com/api/openapi/order/create";

	private static final String queryOrderUrl="http://gift.app.aa.com/api/openapi/order/query";
	
	public static DbxaClient getInstance(String appId, String secret) {
		DbxaClient instance = null;
		if (instanceMap.containsKey(appId)) {
			instance = instanceMap.get(appId);
		} else {
			instance = new DbxaClient(appId, secret);
			instanceMap.put(appId, instance);
		}
		return instance;
	}

	public DbxaClient(String appId, String secret) {
		super();
		this.appId = appId;
		this.secret = secret;
	}

	public synchronized String refreshAccessToken(String appId) {
		accessTokenMap.remove(appId);
		return requireAccessToken(appId);
	}

	/**
	 * 获取访问令牌
	 * @param appId
	 * @return
	 */
	private synchronized String requireAccessToken(String appId) {
		String accessToken = null;
		ExpireValue<String> accessTokenWrap = accessTokenMap.get(appId);
		if (accessTokenWrap != null) {
			accessToken = accessTokenWrap.getValue();
		}
		if (accessToken != null) {
			return accessToken;
		}
		StringBuilder sb = new StringBuilder(accessTokenUrl + "?grant_type=client_credentials&appid=");
		String url = sb.append(appId).append("&secret=").append(secret).toString();
		try {
			HttpClient client = HttpClientBuilder.create().setConnectionTimeToLive(60, TimeUnit.SECONDS).build();
			HttpGet get = new HttpGet(url);
			get.setConfig(RequestConfig.custom().setConnectTimeout(5000)
					.setConnectionRequestTimeout(1000).setSocketTimeout(10000).build());
			logger.info("url:"+url);
			logger.debug(get.getRequestLine());
			HttpResponse response = client.execute(get);
			InputStream in = response.getEntity().getContent();
			BufferedReader br = new BufferedReader(new InputStreamReader(in));
			StringBuilder sb2 = new StringBuilder();
			String line = null;
			while ((line = br.readLine()) != null) {
				sb2.append(line);
			}
			String content = sb2.toString();
			logger.debug(content);
			JsonNode node = mapper.readTree(content);
			if (node.has("token")) {
				accessToken = node.get("token").asText();
				int expiresIn = node.get("expiresIn").asInt() - 200;
				accessTokenMap.put(appId, new ExpireValue<String>(accessToken, expiresIn));
			} else {
				logger.error("获取access_token失败:"+node.toString());
			}
		} catch (Exception e) {
			logger.error("获取access_token失败", e);
		}
		return accessToken;
	}


	/**
	 * 下单
	 * 
	 * @param request
	 * @return
	 */
	public OrderCreateResponse createOrder(OrderCreateRequest request) {
		try {
			String accessToken = requireAccessToken(appId);
			String json = mapper.writeValueAsString(request);
			HttpClient client = HttpClientBuilder.create().setConnectionTimeToLive(60, TimeUnit.SECONDS).build();
			String url = createOrderUrl + "?access_token=" + accessToken;
			HttpPost post = new HttpPost(url);
			post.setConfig(RequestConfig.custom().setConnectTimeout(5000)
					.setConnectionRequestTimeout(1000).setSocketTimeout(10000).build());
			logger.debug(post.getRequestLine());
			post.setEntity(new StringEntity(json, ContentType.APPLICATION_JSON));
			HttpResponse response = client.execute(post);
			InputStream in = response.getEntity().getContent();
			BufferedReader br = new BufferedReader(new InputStreamReader(in));
			String line = null;
			StringBuilder sb = new StringBuilder();
			while((line = br.readLine()) != null){
				sb.append(line);
			}
			logger.debug(sb.toString());
			return mapper.readValue(sb.toString(), OrderCreateResponse.class);
		} catch (IOException e) {
			logger.error("", e);
			System.out.println("向大白小爱下单失败！");
		}
		return null;
	}
	
	public OrderQueryResponse queryOrder(OrderQueryRequest request) {
		try {
			String accessToken = requireAccessToken(appId);
			String json = mapper.writeValueAsString(request);
			HttpClient client = HttpClientBuilder.create().setConnectionTimeToLive(60, TimeUnit.SECONDS).build();
			String url = queryOrderUrl + "?access_token=" + accessToken;
			HttpPost post = new HttpPost(url);
			post.setConfig(RequestConfig.custom().setConnectTimeout(5000)
					.setConnectionRequestTimeout(1000).setSocketTimeout(10000).build());
			logger.info(post.getRequestLine());
			post.setEntity(new StringEntity(json, ContentType.APPLICATION_JSON));
			HttpResponse response = client.execute(post);
			InputStream in = response.getEntity().getContent();
			BufferedReader br = new BufferedReader(new InputStreamReader(in));
			String line = null;
			StringBuilder sb = new StringBuilder();
			while((line = br.readLine()) != null){
				sb.append(line);
			}
			logger.info(sb.toString());
			return mapper.readValue(sb.toString(), OrderQueryResponse.class);
		} catch (IOException e) {
			logger.error("", e);
			System.out.println("向大白小爱查询订单失败！");
		}
		return null;
	}
}

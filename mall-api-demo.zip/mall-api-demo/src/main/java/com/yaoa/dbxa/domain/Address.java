 
package com.yaoa.dbxa.domain;

public class Address {

	private String name;
	
	private String phone;
	
	private int countyId;
	
	private String detail;

	public String getName() {
		return name;
	}

	public String getPhone() {
		return phone;
	}

	public int getCountyId() {
		return countyId;
	}

	public String getDetail() {
		return detail;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public void setCountyId(int countyId) {
		this.countyId = countyId;
	}

	public void setDetail(String detail) {
		this.detail = detail;
	}
	
}

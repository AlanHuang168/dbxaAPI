/*
 * Copyright 2015-2016 Yaoa & Co., Ltd.
 */
package com.yaoa.dbxa.response;

public class OrderCreateResponse {
	
	private int errcode;
	
	private String errmsg;
	
	private String outTradeNo;

	private String orderNo;
	
	public boolean isOk(){
		return errcode == 0;
	}
	
	public int getErrcode() {
		return errcode;
	}

	public String getErrmsg() {
		return errmsg;
	}

	public void setErrcode(int errcode) {
		this.errcode = errcode;
	}

	public void setErrmsg(String errmsg) {
		this.errmsg = errmsg;
	}

	public String getOutTradeNo() {
		return outTradeNo;
	}

	public void setOutTradeNo(String outTradeNo) {
		this.outTradeNo = outTradeNo;
	}

	public String getOrderNo() {
		return orderNo;
	}

	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}

	@Override
	public String toString() {
		return "errcode:" + errcode + " errmsg:" + errmsg + " orderNo:" + orderNo + " outTradeNo:"+outTradeNo;
	}
	
	
}

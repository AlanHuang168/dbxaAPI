package com.yaoa.dbxa.form;

public class OrderCallbackForm {
	
	private String outTradeNo;	//	第三方订单号
	
	private String orderNo;	//	大白小爱订单号
	
	private String orderStatus;	
	
	private String deliveryStatus;
	
	private String sign;
	
	public String getOrderNo() {
		return orderNo;
	}
	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}

	public String getOutTradeNo() {
		return outTradeNo;
	}
	public void setOutTradeNo(String outTradeNo) {
		this.outTradeNo = outTradeNo;
	}
	public String getOrderStatus() {
		return orderStatus;
	}
	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}
	public String getDeliveryStatus() {
		return deliveryStatus;
	}
	public void setDeliveryStatus(String deliveryStatus) {
		this.deliveryStatus = deliveryStatus;
	}

	public String getSign() {
		return sign;
	}
	public void setSign(String sign) {
		this.sign = sign;
	}
	@Override
	public String toString() {
		return "OrderCallbackForm [outTradeNo=" + outTradeNo + ", orderNo=" + orderNo + ", orderStatus=" + orderStatus
				+ ", deliveryStatus=" + deliveryStatus + ", sign=" + sign + "]";
	}

	
}

